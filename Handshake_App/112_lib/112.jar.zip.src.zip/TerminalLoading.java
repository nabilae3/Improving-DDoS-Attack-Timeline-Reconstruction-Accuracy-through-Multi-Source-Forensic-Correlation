/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.io.File;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextArea;
/*     */ 
/*     */ public class TerminalLoading {
/*  12 */   private static final Color HOVER_BLUE = new Color(180, 220, 255); private static final String ICON_URL = "https://cdn-icons-png.flaticon.com";
/*  13 */   private static final Color SELECTED_BLUE = new Color(100, 180, 255);
/*     */   
/*     */   public static void main(String[] args) {
/*  16 */     SwingUtilities.invokeLater(TerminalLoading::showStartWindow);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveToFile(String key, String content) {
/*     */     try {
/*  22 */       File dir = new File("saved_reviews");
/*  23 */       if (!dir.exists()) dir.mkdir();
/*     */       
/*  25 */       FileWriter fw = new FileWriter(new File(dir, key + ".txt"));
/*  26 */       fw.write(content);
/*  27 */       fw.close();
/*  28 */     } catch (Exception e) {
/*  29 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String loadFromFile(String key, String defaultText) {
/*     */     try {
/*  35 */       File file = new File("saved_reviews/" + key + ".txt");
/*  36 */       if (!file.exists()) return defaultText;
/*     */       
/*  38 */       BufferedReader br = new BufferedReader(new FileReader(file));
/*  39 */       StringBuilder sb = new StringBuilder();
/*     */       
/*     */       String line;
/*  42 */       while ((line = br.readLine()) != null) {
/*  43 */         sb.append(line).append("\n");
/*     */       }
/*     */       
/*  46 */       br.close();
/*  47 */       return sb.toString();
/*  48 */     } catch (Exception e) {
/*  49 */       return defaultText;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void setWindowIcon(JFrame frame) {
/*     */     
/*  55 */     try { frame.setIconImage((new ImageIcon(new URL("https://cdn-icons-png.flaticon.com"))).getImage()); } catch (Exception exception) {}
/*     */   }
/*     */   
/*     */   static class BackgroundPanel extends JPanel {
/*     */     private Image backgroundImage;
/*     */     
/*     */     public BackgroundPanel(LayoutManager layout, String imageUrl) {
/*  62 */       super(layout);
/*     */       try {
/*  64 */         URLConnection conn = (new URL(imageUrl)).openConnection();
/*  65 */         conn.setRequestProperty("User-Agent", "Mozilla/5.0");
/*  66 */         this.backgroundImage = ImageIO.read(conn.getInputStream());
/*  67 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/*     */     protected void paintComponent(Graphics g) {
/*  71 */       super.paintComponent(g);
/*  72 */       if (this.backgroundImage != null) {
/*  73 */         g.drawImage(this.backgroundImage, 0, 0, getWidth(), getHeight(), this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void showStartWindow() {
/*  79 */     JFrame frame = new JFrame("System Prompt");
/*  80 */     setWindowIcon(frame);
/*     */     
/*  82 */     String linuxBg = "https://upload.wikimedia.org/wikipedia/commons/a/af/Tux.png";
/*  83 */     BackgroundPanel bg = new BackgroundPanel(new BorderLayout(), linuxBg);
/*  84 */     frame.setContentPane(bg);
/*     */     
/*  86 */     JLabel msg = new JLabel("<html><center>Good afternoon!<br><br>Do you like to continue?</center></html>", 0);
/*  87 */     msg.setFont(new Font("Arial", 1, 18));
/*  88 */     msg.setForeground(Color.BLACK);
/*     */     
/*  90 */     JPanel buttons = new JPanel();
/*  91 */     buttons.setOpaque(false);
/*  92 */     JButton yes = new JButton("Yes");
/*  93 */     JButton no = new JButton("No");
/*     */     
/*  95 */     yes.addActionListener(e -> {
/*     */           paramJFrame.dispose(); showRoleSelection();
/*     */         });
/*  98 */     no.addActionListener(e -> showCustomMessage("Good Bye", ()));
/*     */     
/* 100 */     buttons.add(yes);
/* 101 */     buttons.add(no);
/*     */     
/* 103 */     bg.add(msg, "Center");
/* 104 */     bg.add(buttons, "South");
/*     */     
/* 106 */     frame.setSize(600, 500);
/* 107 */     frame.setLocationRelativeTo((Component)null);
/* 108 */     frame.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void showRoleSelection() {
/* 113 */     JFrame frame = new JFrame("Setup Configuration");
/* 114 */     setWindowIcon(frame);
/*     */     
/* 116 */     JPanel mainPanel = new JPanel(new GridLayout(2, 2, 15, 15));
/* 117 */     mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
/*     */     
/* 119 */     JRadioButton sBtn = new JRadioButton("Sender");
/* 120 */     JRadioButton rBtn = new JRadioButton("Receiver");
/* 121 */     JRadioButton cBtn = new JRadioButton("Copy Files");
/* 122 */     JRadioButton vBtn = new JRadioButton("Received Files");
/*     */     
/* 124 */     ButtonGroup group = new ButtonGroup();
/* 125 */     group.add(sBtn); group.add(rBtn); group.add(cBtn); group.add(vBtn);
/*     */     
/* 127 */     JPanel[] boxes = {
/* 128 */         createInteractiveBox(sBtn, "Sender code..."), 
/* 129 */         createInteractiveBox(rBtn, "Receiver code..."), 
/* 130 */         createInteractiveBox(cBtn, "File sender code..."), 
/* 131 */         createInteractiveBox(vBtn, "File receiver code...") }; byte b;
/*     */     int i;
/*     */     JPanel[] arrayOfJPanel1;
/* 134 */     for (i = (arrayOfJPanel1 = boxes).length, b = 0; b < i; ) { JPanel jPanel = arrayOfJPanel1[b]; mainPanel.add(jPanel); b++; }
/*     */     
/* 136 */     sBtn.setSelected(true);
/* 137 */     updateStyles(boxes);
/*     */     
/* 139 */     JButton next = new JButton("Continue");
/* 140 */     next.addActionListener(e -> {
/*     */           paramJFrame.dispose();
/*     */           
/*     */           showTerminalLoading();
/*     */         });
/* 145 */     frame.add(mainPanel, "Center");
/* 146 */     frame.add(next, "South");
/*     */     
/* 148 */     frame.setSize(600, 500);
/* 149 */     frame.setLocationRelativeTo((Component)null);
/* 150 */     frame.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private static JPanel createInteractiveBox(final JRadioButton rb, String review) {
/* 155 */     final JPanel p = new JPanel(new BorderLayout());
/* 156 */     p.setBackground(Color.WHITE);
/* 157 */     p.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
/* 158 */     rb.setHorizontalAlignment(0);
/*     */     
/* 160 */     String key = rb.getText().replaceAll(" ", "_");
/*     */     
/* 162 */     JButton revBtn = new JButton("Review 🔍");
/* 163 */     revBtn.addActionListener(e -> {
/*     */           JFrame rf = new JFrame("Editor - " + paramJRadioButton.getText());
/*     */           
/*     */           rf.setSize(800, 550);
/*     */           
/*     */           rf.setLocationRelativeTo((Component)null);
/*     */           
/*     */           JTextArea ta = new JTextArea(loadFromFile(paramString1, paramString2));
/*     */           
/*     */           ta.setFont(new Font("Monospaced", 0, 14));
/*     */           
/*     */           ta.setBackground(Color.BLACK);
/*     */           
/*     */           ta.setForeground(Color.GREEN);
/*     */           
/*     */           ta.setCaretColor(Color.WHITE);
/*     */           
/*     */           JButton save = new JButton("Save");
/*     */           
/*     */           save.addActionListener(());
/*     */           JButton close = new JButton("Close");
/*     */           close.addActionListener(());
/*     */           JPanel bottom = new JPanel();
/*     */           bottom.add(save);
/*     */           bottom.add(close);
/*     */           rf.add(new JScrollPane(ta), "Center");
/*     */           rf.add(bottom, "South");
/*     */           rf.setVisible(true);
/*     */         });
/* 192 */     p.add(rb, "Center");
/* 193 */     p.add(revBtn, "South");
/*     */     
/* 195 */     MouseAdapter ma = new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent e) {
/* 197 */           rb.setSelected(true);
/* 198 */           TerminalLoading.updateStylesFromChild(p);
/*     */         }
/*     */         public void mouseEntered(MouseEvent e) {
/* 201 */           if (!rb.isSelected()) p.setBackground(TerminalLoading.HOVER_BLUE); 
/*     */         }
/*     */         public void mouseExited(MouseEvent e) {
/* 204 */           if (!rb.isSelected()) p.setBackground(Color.WHITE);
/*     */         
/*     */         }
/*     */       };
/* 208 */     p.addMouseListener(ma);
/* 209 */     rb.addMouseListener(ma);
/*     */     
/* 211 */     return p;
/*     */   }
/*     */   
/*     */   private static void updateStylesFromChild(JPanel child) {
/* 215 */     Container parent = child.getParent();
/* 216 */     JPanel[] boxes = (JPanel[])Arrays.<Component>stream(parent.getComponents())
/* 217 */       .filter(c -> c instanceof JPanel)
/* 218 */       .toArray(paramInt -> new JPanel[paramInt]);
/* 219 */     updateStyles(boxes); } private static void updateStyles(JPanel[] boxes) {
/*     */     byte b;
/*     */     int i;
/*     */     JPanel[] arrayOfJPanel;
/* 223 */     for (i = (arrayOfJPanel = boxes).length, b = 0; b < i; ) { JPanel box = arrayOfJPanel[b];
/* 224 */       JRadioButton rb = (JRadioButton)box.getComponent(0);
/* 225 */       if (rb.isSelected()) {
/* 226 */         box.setBackground(SELECTED_BLUE);
/* 227 */         box.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
/*     */       } else {
/* 229 */         box.setBackground(Color.WHITE);
/* 230 */         box.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public static void showTerminalLoading() {
/* 237 */     JFrame frame = new JFrame("Mirror Loading System");
/* 238 */     setWindowIcon(frame);
/* 239 */     JPanel bg = new JPanel(new BorderLayout());
/* 240 */     bg.setBackground(new Color(30, 30, 30));
/* 241 */     frame.setContentPane(bg);
/*     */     
/* 243 */     JProgressBar pb = new JProgressBar(0, 100);
/* 244 */     pb.setStringPainted(true);
/*     */     
/* 246 */     JTextArea term = new JTextArea(10, 40);
/* 247 */     term.setBackground(Color.BLACK);
/* 248 */     term.setForeground(Color.GREEN);
/* 249 */     term.setFont(new Font("Monospaced", 1, 15));
/*     */     
/* 251 */     bg.add(pb, "North");
/* 252 */     bg.add(new JScrollPane(term), "Center");
/*     */     
/* 254 */     frame.setSize(650, 500);
/* 255 */     frame.setLocationRelativeTo((Component)null);
/* 256 */     frame.setVisible(true);
/*     */ 
/*     */     
/* 259 */     (new Thread(() -> {
/*     */           
/*     */           try { for (int i = 0; i <= 100; i++) {
/*     */               paramJProgressBar.setValue(i);
/*     */               
/*     */               paramJTextArea.append("Loading " + i + "%\n");
/*     */               
/*     */               paramJTextArea.setCaretPosition(paramJTextArea.getDocument().getLength());
/*     */               
/*     */               Thread.sleep(30L);
/*     */             } 
/*     */             
/*     */             paramJFrame.dispose();
/*     */             
/*     */             SwingUtilities.invokeLater(()); }
/* 274 */           catch (Exception e) { e.printStackTrace(); } 
/* 275 */         })).start();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void showCustomMessage(String text, Runnable onClose) {
/* 280 */     JFrame f = new JFrame("Message");
/* 281 */     JLabel l = new JLabel(text, 0);
/* 282 */     JButton ok = new JButton("OK");
/*     */     
/* 284 */     ok.addActionListener(e -> {
/*     */           paramJFrame.dispose();
/*     */           
/*     */           paramRunnable.run();
/*     */         });
/* 289 */     f.add(l, "Center");
/* 290 */     f.add(ok, "South");
/*     */     
/* 292 */     f.setSize(300, 200);
/* 293 */     f.setLocationRelativeTo((Component)null);
/* 294 */     f.setVisible(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\Nabil\Downloads\112.jar.zip!\TerminalLoading.class
 * Java compiler version: 19 (63.0)
 * JD-Core Version:       1.1.3
 */