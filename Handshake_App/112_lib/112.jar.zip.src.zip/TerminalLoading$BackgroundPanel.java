/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.LayoutManager;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BackgroundPanel
/*    */   extends JPanel
/*    */ {
/*    */   private Image backgroundImage;
/*    */   
/*    */   public BackgroundPanel(LayoutManager layout, String imageUrl) {
/* 62 */     super(layout);
/*    */     try {
/* 64 */       URLConnection conn = (new URL(imageUrl)).openConnection();
/* 65 */       conn.setRequestProperty("User-Agent", "Mozilla/5.0");
/* 66 */       this.backgroundImage = ImageIO.read(conn.getInputStream());
/* 67 */     } catch (Exception exception) {}
/*    */   }
/*    */   
/*    */   protected void paintComponent(Graphics g) {
/* 71 */     super.paintComponent(g);
/* 72 */     if (this.backgroundImage != null)
/* 73 */       g.drawImage(this.backgroundImage, 0, 0, getWidth(), getHeight(), this); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Nabil\Downloads\112.jar.zip!\TerminalLoading$BackgroundPanel.class
 * Java compiler version: 19 (63.0)
 * JD-Core Version:       1.1.3
 */